package karasa;

public interface Operation {
    int perform(int num1,int num2);
    char getOperationSymbol();
}
