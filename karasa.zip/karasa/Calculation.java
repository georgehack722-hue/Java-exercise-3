package karasa;

public class Calculation {
    private int num1,num2;
    private Operation operation;

    public Calculation(Operation operation) {
        this.operation = operation;
    }

    public int calculate(int a, int b) {
        this.num1 = a;
        this.num2 = b;
        return operation.perform(a,b);
    }

    public String getOperationString(){
        return num1+ " " + operation.getOperationSymbol() + " " + num2;
    }
}
