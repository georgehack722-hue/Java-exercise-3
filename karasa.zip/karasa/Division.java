package karasa;

public class Division implements Operation {

    @Override
    public int perform(int num1, int num2) {
        if(num2==0){
            System.out.println("Division by zero");
            return Integer.MIN_VALUE;
        }
        else{
            return num1/num2;
        }
    }

    @Override
    public char getOperationSymbol() {
        return '/';
    }
}
