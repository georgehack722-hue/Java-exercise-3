package karasa;

public class Subtraction implements Operation {

    @Override
    public int perform(int num1, int num2) {
        return num1 - num2;
    }

    @Override
    public char getOperationSymbol() {
        return '-';
    }
}
