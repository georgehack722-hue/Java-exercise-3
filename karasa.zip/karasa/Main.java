package karasa;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter A Operation(+ - * /): ");
        String op = scanner.nextLine();

        Operation operation;
        switch (op) {
            case "+": operation = new Addition();break;
            case "-": operation = new Subtraction();break;
            case "*": operation = new Multiplication();break;
            case "/": operation = new Division();break;
            default: System.out.println("Invalid Operation");
            return;
        }

        Calculation calc = new Calculation(operation);
        System.out.println("Enter A Number: ");
        int num1 = scanner.nextInt();
        System.out.println("Enter A Number: ");
        int num2 = scanner.nextInt();

        int result = calc.calculate(num1, num2);
        System.out.println(calc.getOperationString() + " = " + result);
    }
}
