package karasa;

public class Multiplication implements Operation{

    @Override
    public int perform(int num1, int num2) {
        return 0;
    }

    @Override
    public char getOperationSymbol() {
        return 0;
    }
}
